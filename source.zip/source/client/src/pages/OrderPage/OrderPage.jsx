import React from 'react'

export default function OrderPage() {
  return (
    <div>
      <h2>Order</h2>
    </div>
  )
}
