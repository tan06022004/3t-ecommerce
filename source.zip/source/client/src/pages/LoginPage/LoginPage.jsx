import React from 'react'
import LoginCommponent from '../../components/LoginCommponent/LoginCommponent'

const LoginPage = () => {
  return (
    <div>
        <LoginCommponent/>
    </div>
  )
}

export default LoginPage
