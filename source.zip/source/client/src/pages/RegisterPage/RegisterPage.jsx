import React from 'react'
import RegisterComponent from '../../components/RegisterComponent/RegisterComponent'
const RegisterPage = () => {
  return (
    <div>
        <RegisterComponent/>
    </div>
  )
}

export default RegisterPage
