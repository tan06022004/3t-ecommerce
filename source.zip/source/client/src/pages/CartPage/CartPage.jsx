import React from 'react'
import CartProductComponent from '../../components/CartProductComponent/CartProductComponent'

const CartPage = () => {
  return (
    <div>
        <CartProductComponent/>
    </div>
  )
}

export default CartPage
