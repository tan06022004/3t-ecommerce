import React from 'react'
import ProducTypeComponent from '../../components/ProductTypeComponent/ProducTypeComponent'

const ProductTypePage = () => {
  return (
    <div>
      <ProducTypeComponent/>
    </div>
  )
}

export default ProductTypePage
