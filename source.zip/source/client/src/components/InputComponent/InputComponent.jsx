import Input from "antd/es/input/Input";

import React from 'react'

const InputComponent = ({...porps}) => {
  return (
    <div>
      <Input {...porps}>
      </Input>
    </div>
  )
}

export default InputComponent
